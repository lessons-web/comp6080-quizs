# COMP6080 26T3 — Week 2 课件索引

建议观看顺序：01 → 09（按课程页面的前置关系）

## 🌝 CSS
| 文件 | 课程 | 时长 | 要求 | 视频 | 代码 |
|---|---|---|---|---|---|
| 01-Mobile-CSS.pdf | Mobile CSS | 25 min | Mandatory | https://www.youtube.com/watch?v=sdYc7Ig0Lz4 | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/css-mobile/ |
| 02-Using-CSS-Frameworks.pdf | Using CSS Frameworks | 7 min | Mandatory | https://www.youtube.com/watch?v=30cftqvJ7p4 | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/css-frameworks/ |
| 03-Dev-Tools.pdf | Dev Tools | 15 min | Mandatory | https://www.youtube.com/watch?v=33XUwwuPDbw | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/dev-tools/ |

## 🐻 Javascript General
| 文件 | 课程 | 时长 | 要求 | 视频 | 代码 |
|---|---|---|---|---|---|
| 04-Javascript-Language-Features-and-Syntax.pdf | Javascript Language Features & Syntax | 55 min | 前置课 | https://www.youtube.com/watch?v=EYF_S6nY3Jo | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/javascript-syntax-intro/ |
| 05-The-Javascript-Ecosystem.pdf | The Javascript Ecosystem | 21 min | Mandatory | https://www.youtube.com/watch?v=6ozQFDxefXM | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/javascript-ecosystem/ |

## 🐸 NodeJS
| 文件 | 课程 | 时长 | 要求 | 视频 | 代码 |
|---|---|---|---|---|---|
| 06-Node-Package-Manager.pdf | Node Package Manager | 51 min | 前置课 | https://www.youtube.com/watch?v=qgA2L1-nwkQ | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/javascript-npm/ |
| 07-Javascript-Advanced-Functions.pdf | Javascript Advanced Functions | 64 min | Recommended | https://www.youtube.com/watch?v=KwJTe0txB7E | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/javascript-advanced-functions/ |
| 08-NPM-Advanced.pdf | NPM Advanced | 12 min | Recommended | https://www.youtube.com/watch?v=He2gxQIcsL0 | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/javascript-npm-advanced/ |
| 09-Demo-Javascript-NodeJS.pdf | Demo: Javascript – NodeJS (Live) | 120 min | Mandatory | 直播，录像待发布 | https://cgi.cse.unsw.edu.au/~cs6080/raw/lectures/26t3-demo-js-nodejs/ |

## 配套练习 (Tutorials)
- css-dev-tools-manipulate / css-mobile-first-page / css-responsive-site-analyse / css-investigate-page-components
- javascript-arch-browser-node-quiz
- npm-publish-package / node-number-manipulation-1,2,3 / node-momentjs-problem / nodejs-uuid-problem

课程页：https://cgi.cse.unsw.edu.au/~cs6080/26T3/content/lectures/week#2
